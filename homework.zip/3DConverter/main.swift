import Foundation

let application = Application(argumentCount: CommandLine.argc, arguments: CommandLine.arguments)
application.start()
