import Foundation

protocol File {}
