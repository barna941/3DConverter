import Foundation

protocol DataSerializable {
	func serialize() -> Data
}
